//
//  AppDelegate.h
//  HelloWorld
//
//  Created by pacelli on 11/2/15.
//  Copyright (c) 2015 eurecom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

