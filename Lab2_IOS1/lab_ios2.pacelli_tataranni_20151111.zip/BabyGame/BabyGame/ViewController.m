//
//  ViewController.m
//  BabyGame
//
//  Created by tatarann on 11/3/15.
//  Copyright (c) 2015 eurecom. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize rectangle, square, oval, triangle, circle, slot;
@synthesize iRectangle,iSquare, iOval, iTriangle, iCircle;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIColor *background = [[UIColor alloc]initWithPatternImage:[UIImage imageNamed:@"GameBackground.png"]];
    self.view.backgroundColor = background;
    finalPosition[0] = iRectangle.center;
    finalPosition[1] = iSquare.center;
    finalPosition[2] = iOval.center;
    finalPosition[3] = iTriangle.center;
    finalPosition[4] = iCircle.center;
    buttons[0] = rectangle;
    buttons[1]=square;
    buttons[2]=oval;
    buttons[3]=triangle;
    buttons[4]=circle;
    int i;
    for(i=0; i<5; i++){
        isFinal[i]=false;
        initialPosition[i]=buttons[i].center;
        //NSLog(@"posizionefinale %d %f %f\n", i, finalPosition[i].x, finalPosition[i].y);
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction) buttonPressed:(id)sender{
    UIButton * button = (UIButton *)sender;
    originalPosition[button.tag] = button.center;
    //int i = button.tag;
    //NSLog(@"posizioneBottone %d %f %f\n", i, originalPosition[i].x, originalPosition[i].y);
}

-(IBAction)buttonMoved:(id)sender withEvent:(UIEvent *)event{
    UIButton * button = (UIButton *)sender;
    for (UITouch *  touch in [event allTouches]) {
        button.center = [touch locationInView:self.view];
    }
}


-(CGFloat)distanceBetweenPoint:(CGPoint)point1 andPoint:(CGPoint)point2 {
    // we can say this is private since we dont't put its prototype in the .h file
    CGFloat dx = point2.x - point1.x;
    CGFloat dy = point2.y - point1.y;
    return sqrt(dx*dx + dy*dy);
}

-(IBAction)buttonReleased:(id)sender{
    UIButton * button = (UIButton *)sender;

    if([self distanceBetweenPoint:button.center andPoint:finalPosition[button.tag]]<100){
        button.center=finalPosition[button.tag];
        isFinal[button.tag]=true;
        int k=0, i;
        for(i=0; i<5; i++){
            if(isFinal[i]==true)
                k++;
        }
        if(k==5){
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Congratulations!"
                                                            message:@"You completed the game!"
                                                           delegate:self
                                                  cancelButtonTitle:@"Cancel"
                                                  otherButtonTitles:@"Restart", nil];
            [alert show];
        }
            
    }
    else{
       //;
        [UIView animateWithDuration:2.0 animations:^{
            button.frame = CGRectOffset(button.frame, originalPosition[button.tag].x-button.center.x, originalPosition[button.tag].y-button.center.y);
        }];
        button.center=originalPosition[button.tag];
    }
}

- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    if (buttonIndex == 1) {
        int i;
        for(i=0; i<5; i++){
            isFinal[i]=false;
            buttons[i].center = initialPosition[i];
        }
    }
}

@end
